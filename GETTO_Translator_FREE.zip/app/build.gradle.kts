plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gettotranslator"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gettotranslator"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0-free"
    }
}

dependencies {
    implementation("com.google.mlkit:translate:17.0.3")
}
