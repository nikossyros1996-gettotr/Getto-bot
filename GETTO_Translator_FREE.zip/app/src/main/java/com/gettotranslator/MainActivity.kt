package com.gettotranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var greekToEnglish = true
    private lateinit var direction: TextView
    private lateinit var source: TextView
    private lateinit var result: TextView
    private lateinit var status: TextView
    private var translator: Translator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 50, 32, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply { text = "GETTO TRANSLATOR"; textSize = 28f; gravity = Gravity.CENTER; setPadding(0,0,0,25) }
        direction = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER }
        status = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setPadding(0,15,0,10) }
        source = TextView(this).apply { textSize = 18f; setPadding(0,25,0,15) }
        result = TextView(this).apply { textSize = 22f; setPadding(0,10,0,30) }
        val swap = Button(this).apply { text = "🇬🇷  ↔  🇬🇧"; setOnClickListener { greekToEnglish = !greekToEnglish; updateDirection() } }
        val speak = Button(this).apply { text = "🎤  ΜΙΛΑ"; textSize = 20f; setOnClickListener { listen() } }
        val hear = Button(this).apply { text = "🔊  ΑΚΟΥΣΕ ΜΕΤΑΦΡΑΣΗ"; setOnClickListener { speakResult() } }
        layout.addView(title); layout.addView(direction); layout.addView(status); layout.addView(swap); layout.addView(source); layout.addView(result); layout.addView(speak); layout.addView(hear)
        setContentView(layout)
        updateDirection()
    }

    private fun updateDirection() {
        direction.text = if (greekToEnglish) "🇬🇷 Ελληνικά → 🇬🇧 English" else "🇬🇧 English → 🇬🇷 Ελληνικά"
        status.text = "Έτοιμο"
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (greekToEnglish) "el-GR" else "en-US")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (greekToEnglish) "Μίλησε στα Ελληνικά" else "Speak English")
        }
        startActivityForResult(intent, 20)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            source.text = text
            translate(text)
        }
    }

    private fun translate(text: String) {
        val sourceLang = if (greekToEnglish) TranslateLanguage.GREEK else TranslateLanguage.ENGLISH
        val targetLang = if (greekToEnglish) TranslateLanguage.ENGLISH else TranslateLanguage.GREEK
        translator?.close()
        translator = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(sourceLang).setTargetLanguage(targetLang).build())
        status.text = "Κατέβασμα μοντέλου μετάφρασης…"
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                status.text = "Μετάφραση…"
                translator!!.translate(text)
                    .addOnSuccessListener { translated -> result.text = translated; status.text = "Έτοιμο ✓" }
                    .addOnFailureListener { e -> status.text = "Σφάλμα μετάφρασης: ${e.localizedMessage ?: "άγνωστο"}" }
            }
            .addOnFailureListener { status.text = "Δεν κατέβηκε το μοντέλο. Έλεγξε το Internet." }
    }

    private fun speakResult() {
        val text = result.text.toString().trim()
        if (text.isEmpty()) return
        tts.language = if (greekToEnglish) Locale.US else Locale("el", "GR")
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "getto")
    }

    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.US }
    override fun onDestroy() { translator?.close(); tts.stop(); tts.shutdown(); super.onDestroy() }
}
