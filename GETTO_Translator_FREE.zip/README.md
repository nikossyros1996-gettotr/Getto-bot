# GETTO Translator — Free Android version

Ελληνικά ↔ Αγγλικά χωρίς OpenAI API key.

- Φωνή → κείμενο: Android Speech Recognizer
- Μετάφραση: Google ML Kit Translation
- Κείμενο → φωνή: Android Text-to-Speech

Το πρώτο κατέβασμα του μοντέλου μετάφρασης χρειάζεται Internet. Η ποιότητα και η φωνή μπορεί να διαφέρουν από cloud AI υπηρεσίες.
